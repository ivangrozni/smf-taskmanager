[size=3][b][color=maroon]Delegator[/color][/b][/size] by Iskra
[b]Description:[/b] You can use this to tell people what to do

[b]Version 0.1:[/b]
2014 11 09 
Odkrita huda napaka na forum_kopija, na katerem naj bi testirali delegator.
Zato so bila testiranja neuspesna. Krivec je Jaka Perovsek. Pozabil je pobrisat Cache file.


