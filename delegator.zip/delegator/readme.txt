[size=3][b][color=maroon]Delegator[/color][/b][/size] by Iskra
[b]Description:[/b] You can use this to tell people what to do
